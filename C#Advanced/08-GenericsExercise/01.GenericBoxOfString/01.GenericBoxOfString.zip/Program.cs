﻿using System;

namespace _01.GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                Box<string> current = new Box<string>(line);
                Console.WriteLine(current.ToString());
            }

        }
    }
}
