﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballTeamGenerator
{
    public class Endurance : Stat
    {
        public Endurance(byte level) 
            : base(level)
        {
        }
    }
}
