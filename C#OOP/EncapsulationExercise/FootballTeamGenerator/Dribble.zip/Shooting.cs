﻿using System;
namespace FootballTeamGenerator
{
    public class Shooting : Stat
    {
        public Shooting(byte level) 
            : base(level)
        {
        }
    }
}