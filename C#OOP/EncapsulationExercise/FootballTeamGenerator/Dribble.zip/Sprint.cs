﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballTeamGenerator
{
    public class Sprint : Stat
    {
        public Sprint(byte level) 
            : base(level)
        {
        }
    }
}
