﻿using System;
namespace FootballTeamGenerator
{
    public class Dribble : Stat
    {
        public Dribble(byte level) 
            : base(level)
        {
        }
    }
}