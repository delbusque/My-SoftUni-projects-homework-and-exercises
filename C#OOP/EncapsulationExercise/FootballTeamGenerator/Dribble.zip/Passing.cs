﻿using System;
namespace FootballTeamGenerator
{
    public class Passing : Stat
    {
        public Passing(byte level) 
            : base(level)
        {
        }
    }
}